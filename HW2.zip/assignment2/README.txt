To run code:

Open RStudio.
Open assignment2.Rproj
Open a.R


                                                                                        
                                                                                        
                                      ..',;;,..                                         
                                  .:d0XWWNNNNWNKx:.                                     
                              .;d0NNX0d:,...';o0NWNO:.                                  
                      .....:d0NN0x:'.           'kWMWXd.                                
                   'oOKNNNWMMWx'                  lNMMMK.                               
                 .oNMMMMWMMW0XK;                   :XMMNc                               
                 :NMMMMMMWMX;cN0.                   :XMWd                               
                 oWWMMMMWNO; ,NNl;;    'oO0K0Oxl,.  .kWWx                               
                 cWMMMMMWkc:l0WMWNk. .dNMMMMMWNONKo. oNWd                               
                 ;NWX0XNNWMMWNKkc.  .kWMMMMMMMNclNWO'xWWo                               
                .OWK'  .dWMWKc;k0c  cNMMMMMMMMK,.OWKcKWNc                               
               '0WWk,...,dO00000Oo. dWMMMMNKOl. .xKclNMN,                               
              :XWWWMMWNX0Oxoc;'..   .oKNMWXOdllokO,.0MM0.                               
             :XMXc';:ldxOKKXNWWNX0kdc;;;:cldkkdo,  lNMWd                                
            ;XMNc          ..';:ldxO0KXK0Oxl'     .KMMN,                                
           ,KMNo                      ...',,.     dWMWk.                                
          '0MWx.                                 ,XMMX,                                 
         '0WWx.                                 .OWMWo                                  
        .OWWk.                                  cNMWO.                                  
        lNMX'                      .;l.        'KMWO.                                   
        oNWk                      .xWX' cxc   .kWWO.                                    
        oWNl                      ,XWx.;NMK.  lNM0.                         'oOO0Od;.   
       .dWN:                      dWK,.OWNl  'KMX;                        ;OWNl..cXWO.  
       .dWX,                     .KNo.lWWx. .OWWd                       ;OWWO,    lNN;  
       .xWX.                     :N0.'KWO.  oWMX'                     'kWWKc.    .ONx.  
       .dWX.                    .kX:.OWK'  .KMWx.                   .oXWXl.     .kNd.   
       .dWX'                    ;Xx.xWX;   'XMNxcokO0KKXKK0kd:.   .lKWKl.     .cKXc     
        oWN;                   .kK,dNNc    'XMMNKOdddolloxOXWMNO::KWKc.      :0WO'      
        lNNc                   :Xl;XNo     .KW0'   '0Kx.   .'lKWWW0:.      ;OWNd.       
        :NWx                  ,0O.:NO.      ...   .'oXNxcc:;';OXk;.      ;ONWX:         
        .KMK.               ,d0k' .xKo.         ;OXNNWWWMMMWWWW0:.     ;OWMWO'          
         oWWl             ,xo,.  ':.:KO.         .,,,,,,;:cdOXWMWKl.   :kXWW0c.         
         'KMK'            lK0KO,'KWKlOK,                     .,xNWMK;    .':ld0Ko.      
          oWW0.            ..oXKKNdckx,              ,O0'       'OWMXl  .'.. .dNK;      
          .OWW0'              'll'                   ;od'        .0WMX,  ,xKXKd;.       
           .kWWXc                                .;'              cNMWl    ;0Xc         
            .:0WWO;.                            'KNx              ,XMNc     .KN;        
               ;kWWXd,                          .c:.              lNMWkc;,';dNK'        
     .,.        ,XWWWWKd;.                       oKk.           .cXWKkOKKKKK0d'         
    .0XOkc.    lXNk'.oNMWNKxl;..                  ...         'oKN0c.    .              
    .XO.:0Ko..kWK: .lKKl;oONWWWNX0kdl;'.           'Ox.    .cONNk;                      
    .kX; .lKKNNd..:0Xo.    .';lx0XNWWWWXx. 'ccc:;,'':c..,lONN0o.                        
     ;NO.  .od'.;0Xd.         .....'xWMXl .0WXKXNWNNNXXNNXOo,                           
      lXd.   .c0Xx'         .xXNNX00NWK, .dN0' ..';:llc:..                              
       cKx',xXNx,           .OWW00NWNk'  cNK,                                           
        'kNWNx'              lNM0'.'.   ,KN:                                            
          ':.                .kWWx.    '0Nl                                             
                              .xWWd.  'KNl                                              
                               .lXW0odXXc                                               
                                 .xNWNk.                                                
                                   .'.